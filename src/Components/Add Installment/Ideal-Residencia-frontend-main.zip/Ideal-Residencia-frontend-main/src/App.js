import React from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from './Components/login';
import Registeration from './Components/Registeration'

const App = () => {
  return (
    <>
    <Router>
      <Routes>
        <Route path="/register" element={<Registeration/>}/>
        <Route path="/" element={<Login/>}/>
      </Routes>
   
    </Router>
    </>
    
  )
}

export default App